<?php
/**
 * Description of IndexController
 *
 * @author jon
 */
class Admin_IndexController
    extends Zend_Controller_Action
{
    public function indexAction()
    {
	
    }

}