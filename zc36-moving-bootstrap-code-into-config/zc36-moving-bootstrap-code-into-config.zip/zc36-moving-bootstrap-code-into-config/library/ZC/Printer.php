<?php
/**
 * Description of Printer
 *
 * @author jon
 */
class ZC_Printer
{
    public static function printMe()
    {
	return "I am ZC Printer";
    }
}