<?php

class ZC_Form_Element_Phone 
    extends Zend_Form_Element_Xhtml
{
    public $helper = "phoneElement";

}

