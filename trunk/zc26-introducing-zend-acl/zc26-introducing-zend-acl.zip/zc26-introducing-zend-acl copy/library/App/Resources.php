<?php

class App_Resources 
{
	const PUBLICPAGE 	= 'public';
	const ACCOUNT_FREE 	= 'freeaccount';
	const ACCOUNT_PAID 	= 'paidaccount';
	const ADMIN_SECTION = 'adminpages';
}
