<?php

class App_Roles 
{
	const GUEST = "guest";
	const FREE	= "free";
	const PAID  = "paid";
	const ADMIN = "admin";
}
