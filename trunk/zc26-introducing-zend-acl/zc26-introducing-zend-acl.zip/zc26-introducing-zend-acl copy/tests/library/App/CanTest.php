<?php

class App_CanTest extends ControllerTestCase 
{
	public function testCanDoUnitTest()
	{
		$this->assertTrue(true);
	}
}
