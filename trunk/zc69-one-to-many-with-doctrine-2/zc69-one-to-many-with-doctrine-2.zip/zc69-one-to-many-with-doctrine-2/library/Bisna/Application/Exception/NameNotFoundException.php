<?php

namespace Bisna\Application\Exception;

/**
 * NameNotFoundException class.
 *
 * @author Guilherme Blanco <guilhermeblanco@hotmail.com>
 */
class NameNotFoundException extends \Exception
{
}
