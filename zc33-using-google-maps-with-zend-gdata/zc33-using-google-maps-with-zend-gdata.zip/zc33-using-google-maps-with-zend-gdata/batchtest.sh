#!/usr/bin/env bash
#cd ~/Sites/zc/tests
phpunit --configuration phpunit.xml $1 $2 
#phpunit $1 $2 $3 
